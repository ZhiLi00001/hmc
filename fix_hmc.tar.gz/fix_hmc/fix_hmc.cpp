/* ----------------------------------------------------------------------
   LAMMPS - Large-scale Atomic/Molecular Massively Parallel Simulator
   http://lammps.sandia.gov, Sandia National Laboratories
   Steve Plimpton, sjplimp@sandia.gov
   Copyright (2003) Sandia Corporation.  Under the terms of Contract
   DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
   certain rights in this software.  This software is distributed under
   the GNU General Public License.
   See the README file in the top-level LAMMPS directory.
------------------------------------------------------------------------- */
/* ----------------------------------------------------------------------
   Contributing authors: Zhi Li and Sandro Scandolo (ICTP)

------------------------------------------------------------------------- */

#include "fix_hmc.h"
#include "atom.h"
#include "force.h"
#include "pair.h"
#include "bond.h"
#include "angle.h"
#include "dihedral.h"
#include "improper.h"
#include "kspace.h"
#include "domain.h"
#include "memory.h"
#include "error.h"
#include "comm.h"
#include "random_park.h"
#include "update.h"
#include "modify.h"
#include "fix.h"
#include "group.h"
#include "compute.h"
#include "output.h"
#include "neighbor.h"
#include "change_box.h"
#include "fix_nh.h"
#include <cstring>
#include <math.h> 
#include <stdio.h>
#include <string.h>

#include <iostream>
#include <fstream>
#include <cfloat>
#include <iomanip>
#include "change_box.h"

using namespace LAMMPS_NS;
using namespace FixConst;

FixHMC::FixHMC(LAMMPS *lmp, int narg, char **arg) :
  Fix(lmp, narg, arg),random_equal(NULL), random_unequal(nullptr)
{
  is_debug = false; // debug	
  is_NPT = false; // NPT simulations
  is_SWAP = false; // the atom-swapping move
  is_transmutation = false; // pair transmutation 
  is_hybrid = false; // pair hybrid 
  seed = 2000; // random number seed

  // Retrieve user-defined options:
  nevery = utils::inumeric(FLERR, arg[3], false, lmp);        // Number of MD steps per MC step
  int iarg=4; 
  
  while (iarg < narg) {
      if (strcmp(arg[iarg], "seed") == 0) {
        if (iarg + 2 > narg) error->all(FLERR, "Illegal fix hmc command");
        iarg++; 
        seed = utils::inumeric(FLERR, arg[iarg], false, lmp);      // Seed for random number generation  
      } else if (strcmp(arg[iarg], "t") == 0) {
        if (iarg + 2 > narg) error->all(FLERR, "Illegal fix hmc command");
        iarg++; 
        temperature = utils::numeric(FLERR, arg[iarg], false, lmp);   // System temperature
      } else if (strcmp(arg[iarg], "npt") == 0) {
	is_NPT = true;
      } else if (strcmp(arg[iarg], "nvt") == 0) {
        is_NPT = false;  
      } else if (strcmp(arg[iarg], "debug") == 0) {
        is_debug = true;
      } else if (strcmp(arg[iarg], "swap") == 0) {
        if (iarg + 2 > narg) error->all(FLERR, "Illegal fix hmc command");
	is_SWAP = true;	
        iarg++;
        num_pair = utils::inumeric(FLERR, arg[iarg], false, lmp);
        if (iarg + 2*num_pair > narg) error->all(FLERR, "Illegal fix hmc command"); 
	memory->create(my_type, num_pair, 2, "hmc:my_type");
        for (int i = 0; i < num_pair; i++) {
          for (int j = 0; j < 2; j++) {
	    iarg++;
	    my_type[i][j] = utils::inumeric(FLERR, arg[iarg], false, lmp);
	  }
	}
      } else if (strcmp(arg[iarg], "ratio") == 0) {
        if (iarg + 2 > narg) error->all(FLERR, "Illegal fix hmc command");
	iarg++;
        swap_ratio = utils::numeric(FLERR, arg[iarg], false, lmp);     
      } else if (strcmp(arg[iarg], "scale") == 0) {
        if (iarg + 2 > narg) error->all(FLERR, "Illegal fix hmc command");
        iarg++; 
        scale_sub = utils::numeric(FLERR, arg[iarg], false, lmp);
      } else {
	  if (comm->me == 0) utils::logmesg(lmp, " command = {}", arg[iarg]);     
          error->all(FLERR, "Illegal pair transmutation command");
      }
      iarg++;
  }     

  // check fix NPT is defined before fix HMC  
  Fix **fixes = modify->fix;
  if(is_NPT == true) {
    my_id = modify->find_fix_by_style("^nph");
    if(my_id == -1) error->all(FLERR,"fix hmc must be defined after a NPT command");
  }

  if(is_NPT == false) {
    my_id = modify->find_fix_by_style("^nve");
    if(my_id == -1) error->all(FLERR,"fix hmc must be defined after a nve command");
  }

  // boltzmann constant   
  KT = force->boltz * temperature / force->mvv2e;      // K*T in mvv units
  mbeta = -1.0/(force->boltz * temperature);           // -1/(K*T) in energy units

  // Initialize RNG with a different seed for each process:
  random_unequal = new RanPark(lmp,seed + comm->me);
  random_equal = new RanPark(lmp,seed);
 
  // initialize position arrays
  xu = NULL ;
  xold = NULL ; 
  // Register callback: 
  atom->add_callback(0);
   
  // Define non-default fix attributes:
  global_freq = 1;
  
  scalar_flag = 1;
  vector_flag = 1;   
    
  extscalar = 0;
  extvector = 0;
  size_vector = 1;
     
  // add new computes                  
  // Potential energy   
  id_pe = std::string(id) + "_pe";
  pe = modify->add_compute(id_pe + " all pe");
  pe->addstep(update->ntimestep);
 
  // Kinetic energy   
  id_kinetic = std::string(id) + "_kinetic";
  ke = modify->add_compute(id_kinetic + " all ke");
  ke->addstep(update->ntimestep);           
  
  // temperature               
  id_temp = std::string(id) + "_temp";
  temp = modify->add_compute(id_temp + " all temp ");
  temp->init();
  temp->setup();
  temp->addstep(update->ntimestep);

  // System static pressure without temperature 
  id_press = std::string(id) + "_press";
  press = modify->add_compute(id_press + " all pressure NULL virial");
  press->addstep(update->ntimestep); 

  // set up a compute for energies for two subsystems
  // in a pair transmutation style 
  if (utils::strmatch(force->pair_style,"^transmutation")) {
    is_transmutation = true;
    id_sub_one = std::string(id) + "_energy_one";
    energy_sub_one = modify->add_compute(id_sub_one + " all pair transmutation evdwl");
    energy_sub_one->addstep(update->ntimestep);
    id_sub_two = std::string(id) + "_energy_two";
    energy_sub_two = modify->add_compute(id_sub_two + " all pair transmutation ecoul");
    energy_sub_two->addstep(update->ntimestep);    
  }

  // in a hybrid/scale
  if (utils::strmatch(force->pair_style,"^hybrid/scaled")) {
    is_hybrid = true;
    scale_sub = 1.0;
    id_sub_one = std::string(id) + "_energy_one";
    energy_sub_one = modify->add_compute(id_sub_one + " all pair deepmd 1");
    energy_sub_one->addstep(update->ntimestep);
    id_sub_two = std::string(id) + "_energy_two";
    energy_sub_two = modify->add_compute(id_sub_two + " all pair deepmd 2");
    energy_sub_two->addstep(update->ntimestep);
  }  
  // initialize some arrays               
  tune_flag = 1;

  nattempts = 0;
  naccepts = 0;
  nhmc_attempts = 0;
  nhmc_successes = 0;
 
  // whether the current trial configuration is accepted 
  accept = 0; 

  // register for the next all for the computes like compute pressure
  next_call = update->ntimestep;

  // the num of steps for each move: swap or hmc
  num_swap = ceil(floor(1.0/swap_ratio) * swap_ratio);
  num_hmc = floor(1.0/swap_ratio) - num_swap;

  icounter = 0;

  // initialize MC swap part
  if(is_SWAP == true) {
    nswap_attempts = 0;
    nswap_successes = 0;

    atom_swap_nmax = 0;

    local_swap_iatom_list = nullptr;
    local_swap_jatom_list = nullptr;

    // set comm size needed by this Fix
    if (atom->q_flag) comm_forward = 2;
    else comm_forward = 1;    
  }

  // open new file for writting
  if(comm->me == 0) {
    std::ofstream outfile;
    outfile.open("hmc.dat", std::ios::out);
    outfile << "nattempts naccepts type is_accept nhmc_attempts nhmc_successes ";
    if(is_SWAP == true) outfile << "nswap_attempts nswap_successes ";
    outfile << "oPot nPot oKin nKin Pot_acc ";
    if(is_NPT == true) outfile << "oCoup nCoup ";
    outfile << "delta_E ";
    outfile << "rand_num ";
    if(is_NPT == true) outfile << "lx ly lz xy xz yz ";
    outfile << "ave_pres ";
    if(is_transmutation == true or  is_hybrid == true) outfile << "energy_one energy_two";
    outfile << std::endl;
    
    outfile.close();
  }

  // write some information to the screen
  if (comm->me == 0) {
    utils::logmesg(lmp, " >>> Info of fix hmc (Zhi Li and Sandro Scandolo (ICTP))\n");
    utils::logmesg(lmp, " \t Parameters used in fix hmc:\n");
    utils::logmesg(lmp, " \t \t NPT? = {}, (if false, then NVT simulations)\n", is_NPT);
    utils::logmesg(lmp, " \t \t atom swap? = {}, (if false, then no atom swapping)\n", is_SWAP);
    if(is_SWAP == true){
      for (int i = 0; i < num_pair; i++) {
        utils::logmesg(lmp, " \t \t \t atom swap between type {} and type {} \n", my_type[i][0], my_type[i][1]);
      }	    
      utils::logmesg(lmp, " \t \t num_swap = {} / num_hmc = {} \n", num_swap, num_hmc);
    }
    utils::logmesg(lmp, " \t \t Temperature [K] = {} / random number seed  = {} \n", temperature, seed);
    if(is_transmutation == true) utils::logmesg(lmp, " \t \t pair transmutation is used\n");
    if(is_hybrid == true) utils::logmesg(lmp, " \t \t pair hybrid/scaled is used\n");
    utils::logmesg(lmp, " >>> end of fix HMC \n");
  }
}
/* ---------------------------------------------------------------------- */

FixHMC::~FixHMC()
{
  atom->delete_callback(id,0);
  memory->destroy(xu);
  memory->destroy(xold);
  if(is_SWAP == true) {
    memory->destroy(my_type);
    memory->destroy(local_swap_iatom_list);
    memory->destroy(local_swap_jatom_list);
    if (atom->q_flag) memory->destroy(qtype);
  }
  delete random_equal;
  delete random_unequal; 

  // for unknows reasons, the following commands conflicts with write_data 
  // modify->delete_compute("id_press");
  // modify->delete_compute("id_press_out");
  // modify->delete_compute("id_temp");
  // modify->delete_compute("id_kinetic");
  // modify->delete_compute("id_pe"); 
}
                 
/* ---------------------------------------------------------------------- */

void FixHMC::tune_parameter(int *parameter, const char *name)
{
  if (*parameter % nevery != 0) {
    if (tune_flag) {
      *parameter = (*parameter / nevery + 1)*nevery;
      if (comm->me == 0) utils::logmesg(lmp, "Fix HMC: adjusting {} to {}\n",name, *parameter);
    }
    else {
      if (comm->me == 0) utils::logmesg(lmp, "Fix HMC: {} is not a multiple of nevery\n",name);
      error->all(FLERR,"illegal parameter value");
    }
  }
}

void FixHMC::init()
{
  int ntimestep = update->ntimestep;

  // Check conformance of run length:
  tune_parameter( &update->nsteps, "number of steps of the run" );
  update->laststep = ntimestep + update->nsteps;

  // Check conformance of thermo interval:
  if (output->var_thermo)
    error->all(FLERR,"fix HMC does not allow a variable thermo interval");
  else if (output->thermo_every)
    tune_parameter( &output->thermo_every, "thermo interval" );

  // Check conformance of restart interval:
  if (output->restart_flag) {
    if (output->restart_flag_single)
      tune_parameter( &output->restart_every_single, "restart interval" );
    if (output->restart_flag_double)
      tune_parameter( &output->restart_every_double, "restart interval" );
  }

  // Check conformance of dump interval:
  for (int i = 0; i < output->ndump; i++)
    tune_parameter( &output->every_dump[i], "dump interval" );

  // Check whether there are subsequent fixes with active virial_flag:
  int first = modify->find_fix(this->id) + 1;
  for (int i = first; i < modify->nfix; i++)
    if (modify->fix[i]->virial_global_flag) {
      if (comm->me == 0) utils::logmesg(lmp, "Fix {} defined after fix hmc.\n", modify->fix[i]->style);
      error->all(FLERR,"fix hmc cannot precede fixes that modify the system pressure");
    }
  
  // check fix NPT is defined before fix HMC  
  Fix **fixes = modify->fix;
  my_id = modify->find_fix_by_style("^nph");
  if(is_NPT == true and my_id == -1) error->all(FLERR,"fix hmc must be defined after a NPT command");

  // (Re)allocate array of per-atom properties: 
  grow_arrays(atom->nmax);

  // store position from xu --> xold in 0-1 lamda coords
  atom_positions(); 
  for (int i = 0; i < atom->nlocal; i++)
      memcpy(xold[i], xu[i], sizeof(double) * 3);

  // intialize atom velocities
  random_velocities();
  
  // NPT part
  // store simulation box information
  if(is_NPT == true) {
      memcpy(boxlo, domain->boxlo, sizeof(double) * 3);
      memcpy(boxhi, domain->boxhi, sizeof(double) * 3);
      xy =  domain->xy;
      xz =  domain->xz;
      yz =  domain->yz;
  }
  
  // atom swap part
  if(is_SWAP == true) {
    // vanity check
    // 1. user-defined swap type is not included in the defined system
    int *type = atom->type;
    for (int i = 0; i < num_pair; i++) {
      if (my_type[i][0] <= 0 || my_type[i][0] > atom->ntypes)
        error->all(FLERR,"Invalid atom type in fix atom/swap command");
      if (my_type[i][1] <= 0 || my_type[i][1] > atom->ntypes)
        error->all(FLERR,"Invalid atom type in fix atom/swap command"); 
    }   
    // 2. whether swapped atom has charge
    if (atom->q_flag) {
      double qmax,qmin;
      int firstall,first;
      memory->create(qtype, num_pair, 2,"hmc:qtype");
      for (int iid = 0; iid < 2; iid++) {
        for (int iswaptype = 0; iswaptype < num_pair; iswaptype++) {	      
          first = 1;
          for (int i = 0; i < atom->nlocal; i++) {
            if (atom->mask[i] & groupbit) {
              if (type[i] == my_type[iswaptype][iid]) {
                if (first) {
                  qtype[iswaptype][iid] = atom->q[i];
                  first = 0;
                } else if (qtype[iswaptype][iid] != atom->q[i])
                  error->one(FLERR,"All atoms of a swapped type must have the same charge.");
              }
            }
          }
          MPI_Allreduce(&first,&firstall,1,MPI_INT,MPI_MIN,world);
          if (firstall) error->all(FLERR,"At least one atom of each swapped type must be present to define charges.");
          if (first) qtype[iswaptype][iid] = -DBL_MAX;
          MPI_Allreduce(&qtype[iswaptype][iid],&qmax,1,MPI_DOUBLE,MPI_MAX,world);
          if (first) qtype[iswaptype][iid] = DBL_MAX;
          MPI_Allreduce(&qtype[iswaptype][iid],&qmin,1,MPI_DOUBLE,MPI_MIN,world);
          if (qmax != qmin) error->all(FLERR,"All atoms of a swapped type must have same charge.");
        } // iswaptype
      } // iid
    } // atom->q_flag
    
    // check to see if itype and jtype cutoffs are the same
    // if not, reneighboring will be needed between swaps

    double **cutsq = force->pair->cutsq;
    unequal_cutoffs = false;
    for (int iswaptype = 0; iswaptype < num_pair; iswaptype++)
      for (int ktype = 1; ktype <= atom->ntypes; ktype++)
        if (cutsq[my_type[iswaptype][0]][ktype] != cutsq[my_type[iswaptype][1]][ktype])
          unequal_cutoffs = true;
  } // is_SWAP == true   
}

void FixHMC::setup(int vflag)
{
  // --- Compute properties for the initial state --- //
  // NVT
  potential = pe->compute_scalar();
  kinetic = ke->compute_scalar();
  etotal =  potential + kinetic; 
  pressure = press->compute_scalar(); // static pressure
  acc_pot = potential;

  if(is_transmutation == true) {
    energy_one = energy_sub_one->compute_scalar() / scale_sub; 
    energy_two = energy_sub_two->compute_scalar() / (1.0 - scale_sub);  
  }
 
  if(is_hybrid == true) {
    energy_one = energy_sub_one->compute_scalar() / scale_sub;
    energy_two = energy_sub_two->compute_scalar() / scale_sub;
  }

  // for NPT
  ecouple = 0.0;
  econserve = 0.0;

  if(is_NPT == true) {
    if (domain->dimension == 3)
      volume = domain->xprd * domain->yprd * domain->zprd;
    else
      volume = domain->xprd * domain->yprd;

    // reset barostat velocity 
    double *myptr, buf[7];
    int temp_int = 0;

    buf[0] = temperature;
    for (int i = 0; i < 6; i++){
       buf[i+1] = random_unequal->gaussian();
    }

    MPI_Bcast(&buf, 7, MPI_DOUBLE, 0, world);
    myptr = buf;

    Fix **fixes = modify->fix;
    my_id = modify->find_fix_by_style("^nph");
    fixes[my_id]->reset_parameter(&temp_int, myptr);

    if(my_id >= 0) {
      ecouple = fixes[my_id]->compute_scalar();
      econserve = ecouple + etotal;
    }
  }
  
  // Activate potential energy and other necessary calculations
  int nextstep = update->ntimestep + nevery;
  pe->addstep(nextstep); 
  ke->addstep(nextstep); 
  press->addstep(nextstep); 
  temp->addstep(nextstep);
  if(is_transmutation == true or is_hybrid == true) { 
    energy_sub_one->addstep(nextstep);
    energy_sub_two->addstep(nextstep);
  }
  next_call = nextstep; 
  
}

void FixHMC::end_of_step()
{  
  if (next_call != update->ntimestep) return;	  
  
  // perform hmc
  icounter++; 
  nattempts++;
  run_type = 0;
  atempt_hmc();

  // perform atom swap if needed
  if(is_SWAP == true and icounter == num_hmc) {
    run_type = 1;
    
    kinetic = 0.0; 
    n_kinetic = 0.0;
    ecouple = 0.0;
    n_ecouple = 0.0;

    rebuild_neighbor();

    for (int i = 0; i < num_swap; i++) {
      for (int j = 0; j < num_pair; j++) {
        nattempts++; 
        // rebuild_neighbor();
	update_swap_atoms_list(j);
        attempt_swap(j);
      }	
    }

    // reset icounter to zero
    icounter = 0;  
    // reset neighbor list        
    rebuild_neighbor();
    // get energy
    energy_full();
  }

  // re-set atomic and other (barostat) velocities
  reset_velocity();
}

void FixHMC::reset_velocity()
{
  random_velocities();

  potential = pe->compute_scalar();
  kinetic = ke->compute_scalar();
  etotal =  potential + kinetic;
  pressure = press->compute_scalar();

  if(is_transmutation == true) {
    energy_one = energy_sub_one->compute_scalar() / scale_sub;
    energy_two = energy_sub_two->compute_scalar() / (1.0 - scale_sub);
  }

  if(is_hybrid == true) {
    energy_one = energy_sub_one->compute_scalar() / scale_sub;
    energy_two = energy_sub_two->compute_scalar() / scale_sub;
  }

  if (domain->dimension == 3)
    volume = domain->xprd * domain->yprd * domain->zprd;
  else
    volume = domain->xprd * domain->yprd;

  ecouple = 0.0;
  econserve = 0.0;

  // reset barostat velocity
  if(is_NPT == true) {
    Fix **fixes = modify->fix;
    my_id = modify->find_fix_by_style("^nph");
    int temp_num = 0;
    int *temp_mpchain = (int *)fixes[my_id]->extract("mpchain", temp_num);

    int mpchain = *temp_mpchain;

    temp_num = 6 + 1 + mpchain;
    double *myptr, buf[temp_num];

    buf[0] = temperature;
    for (int i = 0; i < (6+mpchain); i++) {
      buf[i+1] = random_unequal->gaussian();
    }

    MPI_Bcast(&buf, temp_num, MPI_DOUBLE, 0, world);
    myptr = buf;

    int temp_int;
    fixes[my_id]->reset_parameter(&temp_int, myptr);
    
    if(my_id >= 0) {
      ecouple = fixes[my_id]->compute_scalar();
      econserve = ecouple + etotal;
    }
  }  

  // register for next call
  int nextstep = update->ntimestep + nevery;
  if (nextstep <= update->laststep) {
    pe->addstep(nextstep);
    press->addstep(nextstep);
    ke->addstep(nextstep);
    temp->addstep(nextstep);

    if(is_transmutation == true or is_hybrid == true) {
      energy_sub_one->addstep(nextstep);
      energy_sub_two->addstep(nextstep);
    }

    next_call = nextstep;
  }
}

void FixHMC::atempt_hmc()
{
  int i;
  int nlocal = atom->nlocal;
  int ntotal = nlocal + atom->nghost;
  double **x = atom->x;
  Fix **fixes = modify->fix;

  nhmc_attempts++;

  // get positions
  atom_positions();

  // Compute potential and kinetic energy variations:
  n_potential = pe->compute_scalar();
  n_kinetic = ke->compute_scalar();
  n_etotal = n_potential + n_kinetic;
  n_pressure = press->compute_scalar();

  if(is_transmutation == true) {
    n_energy_one = energy_sub_one->compute_scalar() / scale_sub;
    n_energy_two = energy_sub_two->compute_scalar() / (1.0 - scale_sub);
  }

  if(is_hybrid == true) {
    n_energy_one = energy_sub_one->compute_scalar() / scale_sub;
    n_energy_two = energy_sub_two->compute_scalar() / scale_sub;
  }

  n_ecouple = 0.0;
  n_econserve = 0.0;

  if(is_NPT == true){
    // store simulation box information
    memcpy(n_boxlo, domain->boxlo, sizeof(double) * 3);
    memcpy(n_boxhi, domain->boxhi, sizeof(double) * 3);
    n_xy = domain->xy;
    n_xz = domain->xz;
    n_yz = domain->yz;

    if (domain->dimension == 3)
      n_volume = domain->xprd * domain->yprd * domain->zprd;
    else
      n_volume = domain->xprd * domain->yprd;

    my_id = modify->find_fix_by_style("^nph");
    if(my_id >= 0) {
      n_ecouple = fixes[my_id]->compute_scalar();
      n_econserve = n_ecouple + n_etotal;
     }
  }

  // Apply the Metropolis criterion:
  delta_pe = n_potential - potential;
  delta_kinetic = n_kinetic - kinetic;
  delta_etotal = n_etotal - etotal;
  delta_ecouple = n_ecouple - ecouple;
  delta_econserve = n_econserve - econserve;


  rand_num = random_equal->uniform();
  MPI_Bcast(&rand_num, 1, MPI_DOUBLE, 0, world);

  if(is_NPT == false) {
     if(delta_etotal <= 0.0)
       accept = 1;
     else {
       if(rand_num <= exp(mbeta*delta_etotal))
         accept = 1;
       else
         accept = 0;
      }
  }

  if(is_NPT == true) {
     // things are going to get dirty see Shinoda et al., PRB, 2004. Eq. 16       
     // see Martyna, Tobias and Klein, 1994, JCP, Eq. 2.35
     double f_temp;

     f_temp = mbeta*delta_econserve; 
     
     accept = 0 ;
     if(f_temp >= 0.0){
        accept = 1;
     } else if (rand_num <= exp(f_temp)){
        accept = 1;
     }
  }

  MPI_Bcast(&accept,1,MPI_INT,0,world);

  if (accept==1) {
    // Update energy / pressure / volume and save the current state:
    nhmc_successes++;
    naccepts++;

    // pressure
    pressure = n_pressure;    
    
    // energy
    acc_pot = n_potential;

    // subsystem energy if needed
    if(is_transmutation == true or is_hybrid == true) {
        energy_one = n_energy_one;
	energy_two = n_energy_two;
    }	    
    // store atom positions
    for (i = 0; i < atom->nlocal; i++)
        memcpy(xold[i], xu[i], sizeof(double) * 3);

    // box
    if(is_NPT == true) {
        memcpy(boxlo, n_boxlo, sizeof(double) * 3);
        memcpy(boxhi, n_boxhi, sizeof(double) * 3);
        xy =  n_xy;
        xz =  n_xz;
        yz =  n_yz;
        volume = n_volume;
    }
  } else {
    // reset box
    if(is_NPT == true) {
       domain->boxhi[0] = domain->boxlo[0] + (boxhi[0] - boxlo[0]);
       domain->boxhi[1] = domain->boxlo[1] + (boxhi[1] - boxlo[1]);
       domain->boxhi[2] = domain->boxlo[2] + (boxhi[2] - boxlo[2]);
       
       domain->yz = yz;
       domain->xz = xz;
       domain->xy = xy;
       domain->set_global_box();
       domain->set_local_box();
    }

    // Restore saved positions
    for (i = 0; i < atom->nlocal; i++){
       memcpy(x[i], xold[i], sizeof(double) * 3);
    }
 
    // put it back in cartesian coordinate
    domain->lamda2x(atom->nlocal);
  }
  
  // write log
  if(comm->me == 0) write_log();

  if(accept == 0) {
    // rebuild neighbor();
    rebuild_neighbor();
    // energy / force / virial
    energy_full();       
  }	 

  if(is_debug == true and comm->me == 0)
    utils::logmesg(lmp, " for hmc, random number = {}, oPe = {}, nPe = {}, okin = {}, nkin={}, oecouple = {}, necouple={}\n",
                    rand_num, potential, n_potential, kinetic, n_kinetic, ecouple, n_ecouple);
}  

void FixHMC::attempt_swap(int iid)
{
  if ((niswap == 0) || (njswap == 0)) return;

  nswap_attempts++;	
  
  // get old energy
  energy_full(); 
  potential  = pe->compute_scalar(); 
  pressure = press->compute_scalar();
  
  if(is_transmutation == true) {
    energy_one = energy_sub_one->compute_scalar() / scale_sub;
    energy_two = energy_sub_two->compute_scalar() / (1.0 - scale_sub);
  }

  if(is_hybrid == true) {
    energy_one = energy_sub_one->compute_scalar() / scale_sub;
    energy_two = energy_sub_two->compute_scalar() / scale_sub;
  }

  // select atom in type one and atom in type two
  int i = pick_i_swap_atom();
  int j = pick_j_swap_atom();
  int itype = my_type[iid][0];
  int jtype = my_type[iid][1];

  if(i >= 0) {
    int local_i = atom->tag[i];
    if(comm->me == 0) utils::logmesg(lmp, " local atom {} with global id {} and type {} was selected\n", i, local_i, itype);
  }	  
  if(j >= 0) {
    int local_j = atom->tag[j];
    if(comm->me == 0) utils::logmesg(lmp, " local atom {} with global id {} and type {} was selected\n", j, local_j, jtype); 
  }

  // change type / charge
  if (i >= 0) {
    atom->type[i] = jtype;
    if (atom->q_flag) atom->q[i] = qtype[iid][1];
  }
  if (j >= 0) {
    atom->type[j] = itype;
    if (atom->q_flag) atom->q[j] = qtype[iid][0];
  }

  // reset neighbor list if needed
  if (unequal_cutoffs) {
    rebuild_neighbor();	  
  } else {
    comm->forward_comm_fix(this);
  }
  
  rebuild_neighbor(); 

  // get new energy
  energy_full();  
  n_potential = pe->compute_scalar();
  n_pressure = press->compute_scalar();
  
  if(is_transmutation == true) {
    n_energy_one = energy_sub_one->compute_scalar() / scale_sub;
    n_energy_two = energy_sub_two->compute_scalar() / (1.0 - scale_sub);
  }

  if(is_hybrid == true) {
    n_energy_one = energy_sub_one->compute_scalar() / scale_sub;
    n_energy_two = energy_sub_two->compute_scalar() / scale_sub;
  }

  // set random number
  rand_num = random_equal->uniform();
  MPI_Bcast(&rand_num, 1, MPI_DOUBLE, 0, world);

  // metropolis criteria
  delta_pe = n_potential - potential;  
  if (rand_num <= exp(mbeta*delta_pe)) {
    nswap_successes++;
    naccepts++;
    accept = 1;
    pressure = n_pressure;
    
    // subsystem energy if needed
    if(is_transmutation == true or is_hybrid == true) {
        energy_one = n_energy_one;
        energy_two = n_energy_two;
    }

  } else {
    accept = 0;	  
    if (i >= 0) {
      atom->type[i] = my_type[iid][0];
      if (atom->q_flag) atom->q[i] = qtype[iid][0];
    }
    if (j >= 0) {
      atom->type[j] =  my_type[iid][1];
      if (atom->q_flag) atom->q[j] = qtype[iid][1];
    }

    if (unequal_cutoffs) {
      rebuild_neighbor();
    } else {
      comm->forward_comm_fix(this);
    }
  }

  // write log
  if(comm->me == 0) write_log();

  if(is_debug == true and comm->me == 0) 
    utils::logmesg(lmp, " for atom swapping, random number = {}, old energy = {}, new energy = {}, energy change = {}\n", 
		    rand_num, potential, n_potential, exp(mbeta*delta_pe));
}

/* ----------------------------------------------------------------------
------------------------------------------------------------------------- */

int FixHMC::pick_i_swap_atom()
{
  int i = -1;
  double rand_num;
  rand_num = random_equal->uniform();
  MPI_Bcast(&rand_num, 1, MPI_DOUBLE, 0, world);

  int iwhichglobal = static_cast<int> (niswap*rand_num);
  if ((iwhichglobal >= niswap_before) &&
      (iwhichglobal < niswap_before + niswap_local)) {
    int iwhichlocal = iwhichglobal - niswap_before;
    i = local_swap_iatom_list[iwhichlocal];
  }

  return i;
}

/* ----------------------------------------------------------------------
------------------------------------------------------------------------- */

int FixHMC::pick_j_swap_atom()
{
  int j = -1;
  double rand_num;
  rand_num = random_equal->uniform();
  MPI_Bcast(&rand_num, 1, MPI_DOUBLE, 0, world);

  int jwhichglobal = static_cast<int> (njswap*rand_num);
  if ((jwhichglobal >= njswap_before) &&
      (jwhichglobal < njswap_before + njswap_local)) {
    int jwhichlocal = jwhichglobal - njswap_before;
    j = local_swap_jatom_list[jwhichlocal];
  }

  return j;
}

/* ----------------------------------------------------------------------
   update the list of gas atoms
------------------------------------------------------------------------- */

void FixHMC::update_swap_atoms_list(int iid)
{
  int nlocal = atom->nlocal;
  int *type = atom->type;
  double **x = atom->x;

  if (atom->nmax > atom_swap_nmax) {
    memory->sfree(local_swap_iatom_list);
    memory->sfree(local_swap_jatom_list);
    atom_swap_nmax = atom->nmax;
    local_swap_iatom_list = (int *) memory->smalloc(atom_swap_nmax*sizeof(int),
     "hmc:local_swap_iatom_list");
    local_swap_jatom_list = (int *) memory->smalloc(atom_swap_nmax*sizeof(int),
     "hmc:local_swap_jatom_list");
  }

  niswap_local = 0;
  njswap_local = 0;

  for (int i = 0; i < nlocal; i++) {
      if (atom->mask[i] & groupbit) {
        if (type[i] ==  my_type[iid][0]) {
          local_swap_iatom_list[niswap_local] = i;
          niswap_local++;
        } else if (type[i] == my_type[iid][1]) {
          local_swap_jatom_list[njswap_local] = i;
          njswap_local++;
        }
      }
  }

  MPI_Allreduce(&niswap_local,&niswap,1,MPI_INT,MPI_SUM,world);
  MPI_Scan(&niswap_local,&niswap_before,1,MPI_INT,MPI_SUM,world);
  niswap_before -= niswap_local;

  MPI_Allreduce(&njswap_local,&njswap,1,MPI_INT,MPI_SUM,world);
  MPI_Scan(&njswap_local,&njswap_before,1,MPI_INT,MPI_SUM,world);
  njswap_before -= njswap_local;
}

/* ---------------------------------------------------------------------- */

/* ---------------------------------------------------------------------- */

int FixHMC::pack_forward_comm(int n, int *list, double *buf, int /*pbc_flag*/, int * /*pbc*/)
{
  int i,j,m;

  int *type = atom->type;
  double *q = atom->q;

  m = 0;

  if (atom->q_flag) {
    for (i = 0; i < n; i++) {
      j = list[i];
      buf[m++] = type[j];
      buf[m++] = q[j];
    }
  } else {
    for (i = 0; i < n; i++) {
      j = list[i];
      buf[m++] = type[j];
    }
  }

  return m;
}

/* ---------------------------------------------------------------------- */

void FixHMC::unpack_forward_comm(int n, int first, double *buf)
{
  int i,m,last;

  int *type = atom->type;
  double *q = atom->q;

  m = 0;
  last = first + n;

  if (atom->q_flag) {
    for (i = first; i < last; i++) {
      type[i] = static_cast<int> (buf[m++]);
      q[i] = buf[m++];
    }
  } else {
    for (i = first; i < last; i++)
      type[i] = static_cast<int> (buf[m++]);
  }
}


void FixHMC::rebuild_neighbor()
{
  // build up neighbor list
  if (domain->triclinic) domain->x2lamda(atom->nlocal);
  domain->pbc();
  comm->exchange();
  comm->borders();
  if (domain->triclinic) domain->lamda2x(atom->nlocal+atom->nghost);
  if (modify->n_pre_neighbor) modify->pre_neighbor();
  neighbor->build(1);

}	

void FixHMC::energy_full()
{
  // reset / energy / force
  int eflag = 1;
  int vflag = 1;
  
  // clear forces
  const int nall = atom->nlocal + atom->nghost;
  auto f = atom->f;
  memset(&f[0][0], 0, nall * 3 * sizeof(double));

  if (modify->n_pre_force) modify->pre_force(vflag);
  if (force->pair) force->pair->compute(eflag, vflag);
  if (atom->molecular != Atom::ATOMIC) {
    if (force->bond) force->bond->compute(eflag, vflag);
    if (force->angle) force->angle->compute(eflag, vflag);
    if (force->dihedral) force->dihedral->compute(eflag, vflag);
    if (force->improper) force->improper->compute(eflag, vflag);
  }
  if (force->kspace) force->kspace->compute(eflag, vflag);
  if (modify->n_pre_reverse) modify->pre_reverse(eflag,vflag);
  if (force->newton) comm->reverse_comm();
  if (modify->n_post_force) modify->post_force(vflag);
}

void FixHMC::atom_positions()
{
  // atom position in box coordinate 0-1
  int nlocal = atom->nlocal;
  double **x = atom->x;
  
  for (int i = 0; i < nlocal; i++)
    // memcpy(xu[i], x[i], sizeof(double) * 3);
    domain->x2lamda(x[i], xu[i]); 
}

/* ----------------------------------------------------------------------
   Randomly choose velocities from a Maxwell-Boltzmann distribution
------------------------------------------------------------------------- */

void FixHMC::random_velocities()
{
  bool zero_momentum = false;
  bool is_scale = false;
  double **v = atom->v;
  int *type = atom->type;
  int *mask = atom->mask;

  double stdev;
  int nlocal;

  double *rmass = atom->rmass;
  double *mass = atom->mass;
  nlocal = atom->nlocal;
  if (igroup == atom->firstgroup) nlocal = atom->nfirst;
  for (int i = 0; i < nlocal; i++)
    if (mask[i] & groupbit) {
      if (rmass) stdev = sqrt(KT/rmass[i]);
      else stdev = sqrt(KT/mass[type[i]]);
      v[i][0] = stdev*random_unequal->gaussian();
      v[i][1] = stdev*random_unequal->gaussian();
      v[i][2] = stdev*random_unequal->gaussian();
    }

  // compute velocity of center-of-mass of group
  if(zero_momentum == true){
    double masstotal = group->mass(igroup);
    double vcm[3];
    group->vcm(igroup,masstotal,vcm);

    // adjust velocities by vcm to zero linear momentum
    for (int i = 0; i < nlocal; i++)
      if (mask[i] & groupbit) {
        v[i][0] -= vcm[0];
        v[i][1] -= vcm[1];
        v[i][2] -= vcm[2];
      }
  }
  if(is_scale == true) {
    double t_old = temp->compute_scalar();  
    double factor = sqrt(temperature/t_old);
    for (int i = 0; i < nlocal; i++)
      if (mask[i] & groupbit) {
        v[i][0] *= factor;
        v[i][1] *= factor;
        v[i][2] *= factor;
      }
  }    
}

int FixHMC::setmask()
{
  int mask = 0;
  mask |= END_OF_STEP;
  return mask;
}

/* ----------------------------------------------------------------------
   Return the acceptance fraction of proposed MC moves
------------------------------------------------------------------------- */

double FixHMC::compute_scalar()
{
  double acc_frac ;
  acc_frac = naccepts * 1.0 / MAX(1,nattempts);
  return acc_frac;
}

/* ----------------------------------------------------------------------
   Return the acceptance fraction of proposed MC moves, or
   random number used 
   is_accept or not (0 = no, 1= yes)
   current accepted potential
   old potential energy / current potential energy
   old kinetic energy / new kinetic energy
   old total energy / new total energy
   old coupling energy / new coupling energy
   old econserve / new econserve
------------------------------------------------------------------------- */

double FixHMC::compute_vector(int n)
{
  if (n == 0) {
    double acc_frac;
    acc_frac = naccepts * 1.0 / MAX(1,nattempts);
    return acc_frac;
  } else
    return 0.0;
}

double FixHMC::memory_usage()
{
  int nmax = atom->nmax;
  double bytes = 0.0;
  bytes += nmax * 3 * sizeof(double);
  return bytes;
}

void FixHMC::grow_arrays(int nmax)
{
  memory->grow(xold, nmax, 3, "FixHMC:xold");
  memory->grow(xu, nmax, 3, "FixHMC:xnew");
}

void FixHMC::copy_arrays(int i, int j, int delflag)
{
  memcpy(xold[j], xold[i], sizeof(double) * 3);
}

void FixHMC::set_arrays(int i)
{
 memset(xold[i], 0, sizeof(double) * 3);
}

int FixHMC::pack_exchange(int i, double *buf)
{
  int m = 0;
  buf[m++] = xold[i][0];
  buf[m++] = xold[i][1];
  buf[m++] = xold[i][2];

  return m;
}

int FixHMC::unpack_exchange(int nlocal, double *buf)
{
  int m = 0;
  xold[nlocal][0] = buf[m++];
  xold[nlocal][1] = buf[m++];
  xold[nlocal][2] = buf[m++];

  return m;
}

void FixHMC::write_log() {
  std::ofstream outfile;
  outfile.open("hmc.dat", std::ios::app);
  outfile << nattempts << "\t" << naccepts << "\t" << run_type << "\t" << accept << "\t";
  outfile << nhmc_attempts << "\t" << nhmc_successes << "\t";
  if(is_SWAP == true) outfile << nswap_attempts << "\t" << nswap_successes << "\t";
  outfile << std::setprecision(6) << std::fixed << potential << "\t" << n_potential << "\t" << kinetic << "\t" << n_kinetic << "\t" << acc_pot << "\t";
  if(is_NPT == true) outfile << ecouple << "\t" << n_ecouple << "\t";
  if(run_type == 0 and is_NPT == false) outfile << delta_etotal << "\t";
  if(run_type == 0 and is_NPT == true) outfile << delta_econserve << "\t";
  if(run_type == 1) outfile << delta_pe << "\t";
  outfile << rand_num << "\t";
  if(is_NPT == true) outfile << boxhi[0] - boxlo[0] << "\t" << boxhi[1] - boxlo[1] << "\t" << boxhi[2] - boxlo[2] << "\t";
  if(is_NPT == true) outfile << xy << "\t" << xz << "\t" << yz << "\t";  
  outfile << pressure << "\t";
  if(is_transmutation == true or is_hybrid == true) outfile << energy_one << "\t" << energy_two;
  outfile << std::endl; 
  outfile.close();
}

