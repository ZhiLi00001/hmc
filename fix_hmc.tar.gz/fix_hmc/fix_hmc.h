/* ----------------------------------------------------------------------
   LAMMPS - Large-scale Atomic/Molecular Massively Parallel Simulator
   http://lammps.sandia.gov, Sandia National Laboratories
   Steve Plimpton, sjplimp@sandia.gov

   Copyright (2003) Sandia Corporation.  Under the terms of Contract
   DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
   certain rights in this software.  This software is distributed under
   the GNU General Public License.

   See the README file in the top-level LAMMPS directory.
------------------------------------------------------------------------- */

#ifdef FIX_CLASS

FixStyle(hmc,FixHMC)

#else

#ifndef LMP_FIX_HMC_H
#define LMP_FIX_HMC_H

#include "fix.h"

namespace LAMMPS_NS {

class FixHMC : public Fix {
 public:
  FixHMC(class LAMMPS *, int, char **);
  ~FixHMC();
  int setmask();
  void init();
  void setup(int);
  void end_of_step();
  double compute_scalar();
  double compute_vector(int);

  void grow_arrays(int);
  void copy_arrays(int, int, int);
  void set_arrays(int);
  int pack_exchange(int, double *);
  int unpack_exchange(int, double *);
  int pack_forward_comm(int, int *, double *, int, int *);
  void unpack_forward_comm(int, int, double *);

  double memory_usage();
  
 private:

  void tune_parameter(int *, const char *);
  void atom_positions();
  void random_velocities();
  void reset_velocity();
  void atempt_hmc();
  void attempt_swap(int);
  int pick_i_swap_atom();
  int pick_j_swap_atom();
  void update_swap_atoms_list(int);
  void rebuild_neighbor();
  void energy_full();
  void write_log();

  int tune_flag, nevery;
  double temperature, seed;
  bool is_NPT;
  bool is_transmutation, is_hybrid;

  // id for fixes
  std::string id_pe, id_temp, id_kinetic, id_press, id_press_out, id_fix, id_sub_one, id_sub_two;
 
  // special variables to record subsystem energy in pair transmutation
  double energy_one, energy_two, n_energy_one, n_energy_two;
  double scale_sub;

  int run_type; // 0 = hmc / 1 = swap

  // is_debug
  bool is_debug;

  // NPT
  double rand_num_barostat[6];

  // MC
  int next_call, nattempts, naccepts, nhmc_attempts, nhmc_successes, accept;
  double rand_num;
  double delta_etotal, delta_econserve, delta_ecouple, delta_pe, delta_kinetic, DeltaE;
  double KT, mbeta;
  
  // old system
  double potential, kinetic, etotal, ecouple, pressure, volume, econserve;
  double boxlo[3], boxhi[3], xy, xz, yz;
  double **xold;

  // new system
  double n_potential, n_kinetic, n_etotal, n_ecouple, n_pressure, n_volume, n_econserve;
  double n_boxlo[3], n_boxhi[3], n_xy, n_xz, n_yz;
  double **xu;

  // accepted energy
  double acc_pot;

  class RanPark *random_unequal;
  class RanPark *random_equal;

  class Compute *pe;
  class Compute *ke;
  class Compute *temp;
  class Compute *press;
  class Compute *energy_sub_one;
  class Compute *energy_sub_two;
  class Fix *md_fix;
  int my_id = -1;

  // MC: atom swap
  bool is_SWAP;
  int num_pair, **my_type, nswap_attempts, nswap_successes; 
  double swap_ratio;
  double **qtype;
  int atom_swap_nmax;
  int niswap_before, njswap_before;

  int *local_swap_iatom_list;
  int *local_swap_jatom_list;
  int *local_swap_atom_list;
  int niswap, njswap, niswap_local, njswap_local;
  bool unequal_cutoffs;

  int icounter;

  // swap vs hmc
  int num_swap, num_hmc;
};

}

#endif
#endif

/* ERROR/WARNING messages:

*/
